The following python libraries need to be installed to run the program:

- nba_api
- streamlit_option_menu
- json
- plotly
- requests
- streamlit
- pandas
- streamlit_folium
- folium

To install them, open the console and type
```
    pip install -r requirements.txt
```
